package model;
import model.interfaces.IApplicationState;

import java.awt.*;
import java.util.List;
import java.util.ArrayList;
public class ShapeMaker {



    public ShapeList shapeList;
    public List<Shape> masterShapeList;

    
    public List<Shape> selectedShapeList;
    public List<Shape> copyList;
    public List<Shape> movedShapeList;
    public List<Shape> groupList;
    public List<Shape>whiteOutList;
    public IApplicationState appState;
    public Shape shape;
    public Point startPoint,endPoint;


    public ShapeMaker(IApplicationState appState, ShapeList shapeList,List<Shape> selectedShapeList, List<Shape> movedShapeList, List<Shape> copyList,List<Shape>groupList,List<Shape>whiteOutList) {
        this.appState = appState;
        this.shapeList = shapeList;
        this.selectedShapeList = selectedShapeList;
        this.movedShapeList = movedShapeList;
        this.copyList= copyList;
        this.groupList=groupList;
        this.whiteOutList=whiteOutList;

    }

    public void addShape(Shape shape){
        masterShapeList.add(shape);
    }

    public void removeShape (Shape shape){
        masterShapeList.remove(shape);
    }

    public int recentIndex (Shape shape){
        return shapeList.masterShapeList.size()-1;
    }
  
    public List<Shape> getShapeList(){
        return masterShapeList;
    }

    public List<Shape> master(){
        return shapeList.masterShapeList;
    }

    public int getSize(){
        return masterShapeList.size();
    }

    public List<Shape> getSelectList(){
        return selectedShapeList;
    }
    public int getSelectSize(){
        return selectedShapeList.size();
    }

    public void selectAdd(Shape shape){
        selectedShapeList.add(shape);
    }

    public void selectRemove (Shape shape){
        selectedShapeList.remove(shape);
    }

    public void groupAdd (Shape shape){
        groupList.add(shape);
    }

    public void groupRemove (Shape shape){
        groupList.remove(shape);
    }

    public List<Shape> getGroupList(){
        return groupList;
    }

    public int groupSize(){
        return groupList.size();
    }

    public List<Shape> getCopyList(){
        return copyList;
    }
    public void copyAdd(Shape shape){
        this.copyList.add(shape);
    }
    public int copySize(){
        return copyList.size();
    }

    public void drawUpdate(){
        this.shapeList.drawShapeStrategy.update(shapeList.masterShapeList);
    }

    public void cmdUndo(Shape shape){
        shapeList.commandHistoryUndo.add(shape);
    }
    public void cmdRedo(Shape shape){
        shapeList.commandHistoryRedo.add(shape);
    }

    public void move(Shape shape){
        movedShapeList.add(shape);
    }

    public boolean containShape (Shape shape){
        return shapeList.masterShapeList.contains(shape);
    }

    public void moveRepaint (){
        shapeList.drawShapeStrategy.paintCanvas.repaint();
    }
    public void activePrimary(){
        appState.getActivePrimaryColor();
    }
    public void activeSecondary(){
        appState.getActiveSecondaryColor();
    }
    public void activeShading(){
        appState.getActiveShapeShadingType();
    }

    public void activeShape(){
        appState.getActiveShapeType();
    }



    
}













