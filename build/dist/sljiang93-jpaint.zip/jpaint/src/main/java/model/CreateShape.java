package model;

import model.interfaces.ICommand;
import model.interfaces.IUndoable;

import java.awt.*;



public class CreateShape implements ICommand, IUndoable {

    public ShapeMaker shapeMaker;
    public ShapeType shapeType;
    public Point startPoint,endPoint;

    public CreateShape(ShapeMaker shapeMaker, ShapeType shapeType, Point startPoint, Point endPoint) {
        this.shapeMaker = shapeMaker;
        this.shapeType = shapeType;
        this.startPoint = startPoint;
        this.endPoint = endPoint;
    }


    @Override
    public void undo(){
        CommandHistory.undo();

        
    }

    @Override
    public void redo(){
        CommandHistory.redo();

    }

    @Override
    public void run() {
        Shape shape = new Shape(shapeMaker.appState.getActiveShapeType(), startPoint, endPoint, shapeMaker.appState.getActivePrimaryColor(),shapeMaker.appState.getActiveSecondaryColor(), shapeMaker.appState.getActiveShapeShadingType(), null);
        shapeMaker.shapeList.addShape(shape);
        shapeMaker.drawUpdate();
        CommandHistory.add(this);
    }


   
}




