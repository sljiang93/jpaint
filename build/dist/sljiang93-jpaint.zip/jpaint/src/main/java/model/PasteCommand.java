package model;

import model.interfaces.IUndoable;
import model.interfaces.ICommand;
import java.util.ArrayList;
import java.util.List;
import java.awt.Point;

public class PasteCommand implements ICommand,IUndoable{

    public List<Shape> copyList;
    public ShapeList shapeList;
    public Point pasteStart,pasteEnd;
    public Shape copyShape;

    public PasteCommand(ShapeList shapeList, List<Shape> copyList){
        this.shapeList=shapeList;
        this.copyList=copyList;
    }
    @Override
    public void run() {
        

        for(Shape shape: copyList){

            shape.startPoint.x = shape.startPoint.x+ 210;
            shape.endPoint.x = shape.endPoint.x+ 210;
            shape.startPoint.y = shape.startPoint.y+ 225;
            shape.endPoint.y = shape.endPoint.y+ 225;

            Shape copyShape = new Shape(shape.shapeType, shape.startPoint, shape.endPoint, shape.primaryColor, shape.secondaryColor, shape.shadingType, shape.appState);
            shapeList.addShape(copyShape);
            shapeList.updater();
            CommandHistory.add(this);}
        


    }

    @Override
    public void undo() {

        for (Shape shape: copyList){
            shapeList.removeShape(shape);
        }
        
        

        
    }

    @Override
    public void redo() {

        for (Shape shape: copyList){
            shapeList.addShape(shape);
        }

        
    }

    
}
