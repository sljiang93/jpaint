package model.interfaces;

import model.Shape;
import java.awt.*;
import java.util.List;


public interface IDrawShape {
    
    void update(List<Shape> masterShapeList);}

