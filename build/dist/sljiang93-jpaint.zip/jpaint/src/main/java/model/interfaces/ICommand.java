package model.interfaces;

public interface ICommand {
    void run();
}
