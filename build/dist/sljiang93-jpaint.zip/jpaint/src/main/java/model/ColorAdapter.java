package model;
import java.awt.*;
import java.util.*;

public class ColorAdapter {

    public ColorAdapter(ShapeColor shapeColor, EnumMap<ShapeColor, Color> colorEnum) {
        colorEnum.put(ShapeColor.BLACK, Color.BLACK);
        colorEnum.put(ShapeColor.BLUE, Color.BLUE);
        colorEnum.put(ShapeColor.CYAN, Color.CYAN);
        colorEnum.put(ShapeColor.DARK_GRAY, Color.DARK_GRAY);
        colorEnum.put(ShapeColor.GRAY, Color.GRAY);
        colorEnum.put(ShapeColor.GREEN, Color.GREEN);
        colorEnum.put(ShapeColor.LIGHT_GRAY, Color.LIGHT_GRAY);
        colorEnum.put(ShapeColor.MAGENTA, Color.MAGENTA);
        colorEnum.put(ShapeColor.ORANGE, Color.ORANGE);
        colorEnum.put(ShapeColor.PINK, Color.PINK);
        colorEnum.put(ShapeColor.RED, Color.RED);
        colorEnum.put(ShapeColor.WHITE, Color.WHITE);
        colorEnum.put(ShapeColor.YELLOW, Color.YELLOW);
       
    }
}