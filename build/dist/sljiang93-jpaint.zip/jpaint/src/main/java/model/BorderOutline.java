package model;

import model.interfaces.IShape;
import model.ColorAdapter;
import java.awt.*;
import java.util.EnumMap;

public class BorderOutline implements IShape {
    private ShapeColor primaryColor;
    private Graphics2D graphics2d;
    private Shape shape;




    public BorderOutline (ShapeColor primaryColor, Shape shape, Graphics2D graphics2d) {
        this.primaryColor = primaryColor;
        this.shape = shape;
        this.graphics2d = graphics2d;
    }


    @Override
    public void draw() {
        switch(shape.shapeType){
            case RECTANGLE:
                Color primaryR = ColorMap(primaryColor);
                graphics2d.setColor(primaryR);
                graphics2d.setStroke(new BasicStroke(5));
                graphics2d.drawRect(shape.getXMin(), shape.getYMin(), shape.getWidth(), shape.getHeight());
                break;

            case ELLIPSE:
                Color primaryE = ColorMap(primaryColor);
                graphics2d.setColor(primaryE);
                graphics2d.setStroke(new BasicStroke(5));
                graphics2d.drawOval(shape.getXMin(), shape.getYMin(), shape.getWidth(), shape.getHeight());
                break;
                

            case TRIANGLE:
                int[] xO = {shape.getXMin(), shape.getMiddlePoint(), shape.getXMax()};
                int[] yO = {shape.getYMax(), shape.getYMin(), shape.getYMax() };

                Color primaryT = ColorMap(primaryColor);

                graphics2d.setColor(primaryT);
                graphics2d.setStroke(new BasicStroke(5));
                graphics2d.drawPolygon(xO, yO, 3);
                break;

        }

    }

  
    public Color ColorMap(ShapeColor shapeColor) {
        EnumMap<ShapeColor, Color> color = new EnumMap<>(ShapeColor.class);
        new ColorAdapter(shapeColor,color);
        return color.get(shapeColor);
    }


}

