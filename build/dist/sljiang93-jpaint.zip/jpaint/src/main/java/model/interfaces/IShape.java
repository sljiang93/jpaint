package model.interfaces;

import model.ShapeColor;
import model.ColorAdapter;

import java.awt.*;

public interface IShape {
    void draw();

    
}
