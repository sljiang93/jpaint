package model;


import model.interfaces.ICommand;


import java.util.List;

public class CopyCommand implements ICommand {

    public ShapeList shapeList;
    public List<Shape> masterShapeList,selectedShapeList,copyList;


    public CopyCommand(List<Shape> masterShapeList,List<Shape> selectedShapeList, List<Shape> copyList, ShapeList shapeList){
        this.masterShapeList=masterShapeList;
        this.selectedShapeList = selectedShapeList;
        this.copyList = copyList;
        this.shapeList = shapeList;
        
    }

    @Override
    public void run() {

            for(Shape shape: selectedShapeList){
                copyList.add(shape);
        }
        System.out.println("Copy success");



}

}
