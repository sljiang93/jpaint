package model;
import java.awt.*;
import java.util.List;

import model.interfaces.IApplicationState;
import model.interfaces.IDrawShape;
import model.interfaces.IShape;
import view.gui.PaintCanvas;



public class DrawShapeStrategy implements IDrawShape {

    private IShape shapeManipulation;
    private IApplicationState applicationState;
    public PaintCanvas paintCanvas;
    public ShapeColor primaryColor,secondaryColor;


    public DrawShapeStrategy(PaintCanvas paintCanvas, IShape shapeManipulation){
        this.paintCanvas = paintCanvas;
        this.shapeManipulation = shapeManipulation;
    }

    public void update(List<Shape> masterShapeList) {
        Graphics2D graphics2d = paintCanvas.getGraphics2D();

        for(Shape shape: masterShapeList){



            switch(shape.shapeType){
                case RECTANGLE:
                    shapeManipulation = new RectangleStrategy(shape.primaryColor, shape.secondaryColor, shape, graphics2d);
                    break;
                case TRIANGLE:
                    shapeManipulation = new TriangleStrategy(shape.primaryColor, shape.secondaryColor, shape,graphics2d);
                    break;
                case ELLIPSE:
                    shapeManipulation = new EllipseStrategy(shape.primaryColor, shape.secondaryColor, shape, graphics2d);
                    break;



            }

            shapeManipulation.draw();
        }
    }
}
