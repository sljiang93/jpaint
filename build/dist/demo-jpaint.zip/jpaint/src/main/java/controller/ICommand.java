package controller;

public interface ICommand {
    void run();
}
