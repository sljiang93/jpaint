package controller;

public interface IUndoable {
    void undo();
    void redo();
}
