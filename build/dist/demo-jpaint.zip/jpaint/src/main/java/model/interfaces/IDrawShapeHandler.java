package model.interfaces;

import model.Shape;

import java.util.List;

public interface IDrawShapeHandler {
    void update(List<Shape> masterShapeList);
}
