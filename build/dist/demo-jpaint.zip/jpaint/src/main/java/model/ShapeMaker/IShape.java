package model.ShapeMaker;

public interface IShape {
    void update();
}
