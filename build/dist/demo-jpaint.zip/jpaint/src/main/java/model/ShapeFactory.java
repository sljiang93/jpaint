package model;
import model.interfaces.IApplicationState;

import java.awt.*;
import java.util.List;
public class ShapeFactory {

    public IApplicationState appState;
    public ShapeList shapeList;

    public Shape shape;


    public ShapeFactory(IApplicationState appState, ShapeList shapeList) {
        this.appState = appState;
        this.shapeList = shapeList;

    }
}













